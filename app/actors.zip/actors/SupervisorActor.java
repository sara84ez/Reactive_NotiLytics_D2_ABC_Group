package app.actors;

import org.apache.pekko.actor.typed.*;
import org.apache.pekko.actor.typed.javadsl.*;

/**
 * SupervisorActor defines the supervision strategy for the system.
 * It oversees SearchActor, ResourceNewsActor, and UserActor instances.
 * Any errors in child actors are handled here using a restart strategy.
 *
 * Responsibilities:
 *  - Catch exceptions thrown by child actors
 *  - Restart failed actors to maintain system stability
 *  - Ensure reactive pipeline remains live during NewsAPI failures
 *
 * This actor is required for Delivery 2 (SOEN 6441) to ensure proper
 * error-handling during asynchronous operations.
 *
 * @author Sara Ezzati
 */
public class SupervisorActor {

    /**
     * Defines a supervision strategy with automatic restart on failure.
     *
     * @param childBehavior behavior of the supervised actor
     * @param <T> type of messages the child actor handles
     * @return Behavior wrapped with supervision
     */
    public static <T> Behavior<T> supervise(Behavior<T> childBehavior) {
        return Behaviors.supervise(childBehavior)
                .onFailure(Exception.class, SupervisorStrategy.restart());
    }

    /**
     * Convenience method to create a supervised actor.
     *
     * @param childBehavior original child actor behavior
     * @param ctx actor context for spawning
     * @param name name of the supervised child actor
     * @param <T> message type
     * @return reference to spawned supervised actor
     */
    public static <T> ActorRef<T> spawnSupervised(
            Behavior<T> childBehavior,
            ActorContext<?> ctx,
            String name
    ) {
        return ctx.spawn(supervise(childBehavior), name);
    }
}
