package app.actors;

import org.apache.pekko.actor.typed.Behavior;
import org.apache.pekko.actor.typed.ActorRef;
import org.apache.pekko.actor.typed.javadsl.*;

import app.actors.SearchActor.SearchArticles;
import app.actors.SearchActor.SearchResults;
import app.actors.ResourceNewsActor.GetSources;
import app.actors.ResourceNewsActor.SourcesResponse;

import app.models.Article;
import app.models.SourceInfo;

import java.util.*;
import java.util.concurrent.CompletionStage;

/**
 * UserActor manages a single user's session and WebSocket events.
 * One instance of this actor is created for each WebSocket connection.
 * It stores the user's search history, handles duplicate filtering,
 * appends new real-time results, and communicates with SearchActor,
 * ResourceNewsActor, and WebSocketController.
 *
 * This actor is the core of the reactive push (server-push) functionality
 * required for Delivery 2 of SOEN 6441.
 *
 * Responsibilities:
 *  - Maintain user-specific search history
 *  - Send search commands to SearchActor
 *  - Send source-filter commands to ResourceNewsActor
 *  - Receive results and push them to the WebSocket actor
 *  - Filter duplicates
 *  - Append real-time incoming updates
 *
 * @author Sara Ezzati
 */
public class UserActor extends AbstractBehavior<UserActor.Command> {

    /** Marker interface for all UserActor messages. */
    public interface Command {}

    /** External message: user typed a search query. */
    public static final class UserSearch implements Command {
        public final String query;
        public UserSearch(String q) { this.query = q; }
    }

    /** External message: user requests news sources with filters. */
    public static final class UserRequestSources implements Command {
        public final String country;
        public final String category;
        public final String language;

        public UserRequestSources(String c, String cat, String lang) {
            this.country = c;
            this.category = cat;
            this.language = lang;
        }
    }

    /** Internal message: SearchActor returns articles. */
    public static final class IncomingArticles implements Command {
        public final List<Article> articles;
        public IncomingArticles(List<Article> list) { this.articles = list; }
    }

    /** Internal message: ResourceNewsActor returns sources. */
    public static final class IncomingSources implements Command {
        public final List<SourceInfo> sources;
        public IncomingSources(List<SourceInfo> list) { this.sources = list; }
    }

    /** Push data to WebSocketController. */
    public static final class PushToWebSocket implements Command {
        public final String jsonPayload;
        public PushToWebSocket(String json) { this.jsonPayload = json; }
    }

    private final ActorRef<SearchActor.Command> searchActor;
    private final ActorRef<ResourceNewsActor.Command> resourceActor;
    private final ActorRef<PushToWebSocket> websocket;

    private final Set<String> seenArticleIds = new HashSet<>();
    private final List<String> searchHistory = new ArrayList<>();

    /** Create method for DI from WebSocketController. */
    public static Behavior<Command> create(
            ActorRef<SearchActor.Command> search,
            ActorRef<ResourceNewsActor.Command> resource,
            ActorRef<PushToWebSocket> wsRef
    ) {
        return Behaviors.setup(ctx ->
                new UserActor(ctx, search, resource, wsRef)
        );
    }

    private UserActor(
            ActorContext<Command> ctx,
            ActorRef<SearchActor.Command> search,
            ActorRef<ResourceNewsActor.Command> resource,
            ActorRef<PushToWebSocket> wsRef
    ) {
        super(ctx);
        this.searchActor = search;
        this.resourceActor = resource;
        this.websocket = wsRef;
    }

    @Override
    public Behavior<Command> onMessage(Command msg) {

        if (msg instanceof UserSearch m) {
            return onUserSearch(m.query);
        }

        if (msg instanceof UserRequestSources m) {
            return onUserRequestSources(m);
        }

        if (msg instanceof IncomingArticles m) {
            return onIncomingArticles(m.articles);
        }

        if (msg instanceof IncomingSources m) {
            return onIncomingSources(m.sources);
        }

        if (msg instanceof PushToWebSocket m) {
            websocket.tell(m);
            return this;
        }

        return this;
    }

    private Behavior<Command> onUserSearch(String query) {
        searchHistory.add(query);

        if (searchHistory.size() > 10)
            searchHistory.remove(0);

        searchActor.tell(new SearchArticles(query,
                getContext().messageAdapter(SearchResults.class,
                        res -> new IncomingArticles(res.articles))
        ));

        return this;
    }

    private Behavior<Command> onUserRequestSources(UserRequestSources req) {

        resourceActor.tell(
                new GetSources(
                        req.country,
                        req.category,
                        req.language,
                        getContext().messageAdapter(SourcesResponse.class,
                                r -> new IncomingSources(r.sources))
                )
        );

        return this;
    }

    private Behavior<Command> onIncomingArticles(List<Article> list) {

        List<Article> newOnes = new ArrayList<>();

        for (Article a : list) {
            if (!seenArticleIds.contains(a.id)) {
                seenArticleIds.add(a.id);
                newOnes.add(a);
            }
        }

        if (!newOnes.isEmpty()) {
            String json = toJsonArticles(newOnes);
            websocket.tell(new PushToWebSocket(json));
        }

        return this;
    }

    private Behavior<Command> onIncomingSources(List<SourceInfo> list) {
        String json = toJsonSources(list);
        websocket.tell(new PushToWebSocket(json));
        return this;
    }

    private String toJsonArticles(List<Article> list) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"articles\":[");
        for (int i = 0; i < list.size(); i++) {
            Article a = list.get(i);
            sb.append(a.toJson());
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]}");
        return sb.toString();
    }

    private String toJsonSources(List<SourceInfo> list) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"sources\":[");
        for (int i = 0; i < list.size(); i++) {
            sb.append(list.get(i).toJson());
            if (i < list.size() - 1) sb.append(",");
        }
        sb.append("]}");
        return sb.toString();
    }
}
