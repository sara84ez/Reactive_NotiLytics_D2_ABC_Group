package controllers;

import models.IndexViewModel;
import models.SourceViewModel;
import models.WordCount;
import models.WordStatsViewModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import play.mvc.*;

import javax.inject.Inject;
import java.util.UUID;
import java.util.concurrent.CompletionStage;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import play.libs.Json;
import services.NewsApiClient;
import java.util.Optional;


/**
 * @author group members
 * Controller for handling the main application endpoints.
 */

public class HomeController extends Controller {
    private final Logger logger = LoggerFactory.getLogger("application");
    private final IndexViewModel indexViewModel;
    private final SourceViewModel sourceViewModel;
    private final NewsApiClient client;
    private final WordStatsViewModel wordStatsViewModel;

    /**
     * @author Group_ABC
     * @param indexViewModel  The {@link IndexViewModel} used to manage and retrieve news search results.
     * @param sourceViewModel The {@link SourceViewModel} used to manage and retrieve source information and articles.
     * @param client          The {@link NewsApiClient} responsible for fetching sources from the News API.
     */
    @Inject
    public HomeController(IndexViewModel indexViewModel, SourceViewModel sourceViewModel, NewsApiClient client, WordStatsViewModel wordStatsViewModel) {
        this.indexViewModel = indexViewModel;
        this.sourceViewModel = sourceViewModel;
        this.client = client;
        this.wordStatsViewModel = wordStatsViewModel;
    }

    /**
     * Renders the home page of the application.
     * @author Pham Bao Quynh Nguyen
     * @param request The HTTP request containing session information.
     * @return A {@link Result} object that renders the home page with any stored search results.
     */
    public Result index(Http.Request request) {
        // Get or create session ID
        String sessionId = request.session().getOptional("sessionId")
                .orElse(UUID.randomUUID().toString());

        return ok(views.html.index.render(indexViewModel.getResults(sessionId)))
                .addingToSession(request, "sessionId", sessionId);
    }

    /**
     * Handles search requests submitted by the user.
     * @author Pham Bao Quynh Nguyen
     * @param query The search keyword entered by the user.
     * @param sortBy The sorting criterion (e.g., "relevancy", "popularity", or "publishedAt").
     * @param request The incoming HTTP request containing session information.
     * @return A {@link CompletionStage} resolving to a {@link Result} that renders the updated search results.
     */
    public CompletionStage<Result> search(String query, String sortBy, Http.Request request) {
        String sessionId = request.session().getOptional("sessionId")
                .orElse(UUID.randomUUID().toString());

        return indexViewModel.getNews(sessionId, query, sortBy).thenApply(result ->
                ok(views.html.index.render(indexViewModel.getResults(sessionId)))
                        .addingToSession(request, "sessionId", sessionId)
        );
    }

    /**
     * Displays articles and source information for a specific domain.
     * @author Pham Bao Quynh Nguyen
     * @param domain The domain name of the news source
     * @return A {@link CompletionStage} resolving to a {@link Result} that renders the source view containing profile information and recent articles.
     */
    public CompletionStage<Result> source(String domain) {
//        logger.info("Domain received {}", domain);
        CompletionStage<JsonNode> sourceInfoFuture = sourceViewModel.getSourceInfo(domain);
        CompletionStage<List<JsonNode>> topArticlesFuture = sourceViewModel.getTop10ArticlesForSpecificSource(domain);

        return sourceInfoFuture.thenCombine(topArticlesFuture, (sourceProfile, articles) -> {
            return ok(views.html.source.render(sourceProfile, articles, domain));
        });
    }

    /**
     * Returns a view listing news sources, or a JSON payload depending on the requested format.
     *
     * @author Sara Ezzati
     * @param country  optional country code used to filter sources (may be {@code null} or blank)
     * @param category optional category used to filter sources (may be {@code null} or blank)
     * @param language optional language used to filter sources (may be {@code null} or blank)
     * @param format   response format, either {@code "html"} (default) or {@code "json"}
     * @return A {@link CompletionStage<Result>} that renders the HTML sources view or a JSON list of sources.
     */
    public CompletionStage<Result> list(String country, String category, String language, String format) {
            Optional<String> c = Optional.ofNullable(country).filter(s -> !s.isBlank());
            Optional<String> cat = Optional.ofNullable(category).filter(s -> !s.isBlank());
            Optional<String> lang = Optional.ofNullable(language).filter(s -> !s.isBlank());

            return client.getSources(c, cat, lang).thenApply(sources -> {
                if ("json".equalsIgnoreCase(format)) {
                    return ok(Json.toJson(sources)).as("application/json");
                }
                return ok(views.html.sources.render(sources, country == null ? "" : country,
                        category == null ? "" : category, language == null ? "" : language));
            });
        }

    /**
     * REST-style endpoint that exposes the list of news sources as JSON only.
     * <p>
     * This method is intended for programmatic access (e.g. from front-end code
     * or other services) rather than rendering an HTML page.
     * </p>
     *
     * @author Sara Ezzati
     * @param country  optional country code used to filter sources (may be {@code null} or blank)
     * @param category optional category used to filter sources (may be {@code null} or blank)
     * @param language optional language used to filter sources (may be {@code null} or blank)
     * @return A {@link CompletionStage<Result>} that returns a JSON array of sources.
     */
    public CompletionStage<Result> api(String country, String category, String language) {
            Optional<String> c = Optional.ofNullable(country).filter(s -> !s.isBlank());
            Optional<String> cat = Optional.ofNullable(category).filter(s -> !s.isBlank());
            Optional<String> lang = Optional.ofNullable(language).filter(s -> !s.isBlank());

            return client.getSources(c, cat, lang).thenApply(sources -> ok(Json.toJson(sources)).as("application/json"));
        }

    /**
     * REST-style endpoint that exposes the list of words and their count
     *
     * @param query The search keyword entered by the user.
     * @return A {@link CompletionStage<Result>} that returns a JSON array of word statistics.
     */
    public CompletionStage<Result> wordStats(String query) {
        return wordStatsViewModel.getWordCountsForSessionAsync(query)
                .thenApply(result -> {
                    List<WordCount> counts = result.getCounts();
                    return ok(views.html.wordStats.render(counts, query == null ? "" : query));
                });
    }
}
