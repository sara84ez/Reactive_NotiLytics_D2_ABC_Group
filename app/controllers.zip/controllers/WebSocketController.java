package controllers;

import org.apache.pekko.actor.typed.ActorRef;
import org.apache.pekko.actor.typed.javadsl.AskPattern;
import org.apache.pekko.actor.typed.ActorSystem;
import org.apache.pekko.util.Timeout;

import app.actors.UserActor;
import app.actors.SearchActor;
import app.actors.ResourceNewsActor;
import app.actors.SupervisorActor;

import javax.inject.Inject;
import javax.inject.Singleton;

import play.mvc.*;
import play.libs.streams.ActorFlow;
import play.libs.concurrent.HttpExecutionContext;

import java.time.Duration;
import java.util.concurrent.CompletionStage;

/**
 * WebSocketController establishes WebSocket connections and
 * creates a UserActor for each client session.
 *
 * It wires:
 *  - UserActor (per connection)
 *  - SearchActor (shared)
 *  - ResourceNewsActor (shared)
 *
 * Required for Delivery 2 of SOEN 6441.
 *
 * WebSocket protocol:
 *  Incoming text → forwarded to UserActor
 *  Outgoing push messages → sent from UserActor to client
 *
 * Author: Sara Ezzati
 */
@Singleton
public class WebSocketController extends Controller {

    private final ActorSystem<Void> system;
    private final ActorRef<SearchActor.Command> searchActor;
    private final ActorRef<ResourceNewsActor.Command> resourceActor;
    private final Timeout timeout = Timeout.create(Duration.ofSeconds(5));

    @Inject
    public WebSocketController(ActorSystem<Void> system,
                               ActorRef<SearchActor.Command> searchActor,
                               ActorRef<ResourceNewsActor.Command> resourceActor) {
        this.system = system;
        this.searchActor = searchActor;
        this.resourceActor = resourceActor;
    }

    /**
     * Creates the WebSocket endpoint /ws.
     *
     * Each connection spawns a UserActor supervised by SupervisorActor.
     *
     * @return WebSocket instance
     */
    public WebSocket ws() {
        return WebSocket.Text.accept(request -> ActorFlow.actorRef(out ->
                UserActor.create(searchActor, resourceActor, out), system
        ));
    }
}
