package models;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import services.NewsService;

import javax.inject.Inject;
import java.util.*;
import java.util.concurrent.CompletionStage;

/**
 * @author Pham Bao Quynh Nguyen
 * IndexViewModel class responsible for managing and retrieving news search results
 */
public class IndexViewModel {
    private final NewsService newsService;

    // Store results for each session (key = sessionId)
    private final Map<String, List<SearchResult>> sessionResults = new HashMap<>();

    /**
     * Constructs an {@link IndexViewModel} with the specified {@link NewsService}.
     * @param newsService
     */
    @Inject
    public IndexViewModel(NewsService newsService) {
        this.newsService = newsService;
    }

    /**
     * Retrieves the list of news search results for a given session.
     * @param sessionId The unique session ID.
     * @return A list of {@link SearchResult} objects for the session.
     */
    // Retrieve cumulative results for one user's session
    public List<SearchResult> getResults(String sessionId) {
        return sessionResults.getOrDefault(sessionId, new ArrayList<>());
    }

    /**
     * Performs a news search using the provided query and sorting criteria,
     * then stores the results under the corresponding session.
     * Keeps at most 10 recent search results per session.
     *
     * @param sessionId The unique session ID.
     * @param query The search query.
     * @param sortBy The sorting criteria.
     * @return A {@link CompletionStage} resolving to the {@link SearchResult} object.
     */
    // Perform search and store results in the session-specific list
    public CompletionStage<SearchResult> getNews(String sessionId, String query, String sortBy) {
        return newsService.searchNews(query, sortBy).thenApply(json -> {
            ArrayNode articlesArray = (ArrayNode) json.get("articles");
            List<JsonNode> articlesList = new ArrayList<>();

            if (articlesArray != null) {
                articlesArray.forEach(articlesList::add);
            }

            models.SentimentAnalysisResult sentiment = services.SentimentAnalyzer.analyzeStream(articlesList);

            int totalResults = json.has("totalResults") ? json.get("totalResults").asInt() : 0;
            SearchResult result = new SearchResult(query, sortBy, articlesList, totalResults, sentiment);

            // Add result for this user's session (store newest first)
            sessionResults.computeIfAbsent(sessionId, k -> new ArrayList<>()).add(0, result);

            // Ensure only the 10 most recent searches are kept
            List<SearchResult> results = sessionResults.get(sessionId);
            if (results.size() > 10) {
                results.subList(10, results.size()).clear(); // remove older entries beyond the 10th
            }

            return result;
        });
    }


}
