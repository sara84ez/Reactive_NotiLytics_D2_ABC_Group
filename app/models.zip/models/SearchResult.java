package models;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

/**
 * Represents the result of a news search query retrieved from the News API.
 * @author Pham Bao Quynh Nguyen
 * SearchResult represents the result of a news search query.
 */
public class SearchResult {
    public final String query;
    public final String sortBy;
    public final List<JsonNode> articles;
    public final int totalResults;

    public final SentimentAnalysisResult sentiment;

    public SearchResult(String query, String sortBy, List<JsonNode> articles, int totalResults, SentimentAnalysisResult sentiment) {
        this.query = query;
        this.sortBy = sortBy;
        this.articles = articles;
        this.totalResults = totalResults;
        this.sentiment = sentiment;
    }
}
