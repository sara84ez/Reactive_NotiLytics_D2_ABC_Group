package models;

public enum Sentiment {
    HAPPY(":-)"),
    SAD(":-("),
    NEUTRAL(":-|");

    public final String emoji;
    Sentiment(String emoji) { this.emoji = emoji; }
}
