package models;

public class SentimentAnalysisResult {
    public final Sentiment overall;
    public final double happyRatio;
    public final double sadRatio;
    public final int happyCount;
    public final int sadCount;

    public SentimentAnalysisResult(Sentiment overall, double happyRatio, double sadRatio, int happyCount, int sadCount) {
        this.overall = overall;
        this.happyRatio = happyRatio;
        this.sadRatio = sadRatio;
        this.happyCount = happyCount;
        this.sadCount = sadCount;
    }
}
