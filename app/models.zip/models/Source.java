package models;

/**
 * Represents a single news source as returned by the NewsAPI.
 * Each source includes metadata such as ID, name, description,
 * category, language, and country.
 *
 * <p>This model is immutable and is primarily used by {@link services.NewsApiClient}
 * and {@link services.NewsService} to map JSON responses to Java objects.</p>
 *
 * @author Sara Ezzati
 * @version 1.0
 */
public class Source {

    /** Unique identifier of the source (e.g., "bbc-news"). */
    public final String id;

    /** Human-readable name of the source (e.g., "BBC News"). */
    public final String name;

    /** Short description of the source’s content or focus. */
    public final String description;

    /** The homepage URL of the news source. */
    public final String url;

    /** The category of news (e.g., "general", "technology", "sports"). */
    public final String category;

    /** The language code of the source (e.g., "en", "fr"). */
    public final String language;

    /** The country code of the source (e.g., "us", "gb"). */
    public final String country;

    /**
     * Constructs a {@code Source} object.
     *
     * @param id          unique ID of the source
     * @param name        display name of the source
     * @param description a short text describing the source
     * @param url         the main website of the source
     * @param category    the topic category of the source
     * @param language    the ISO language code of the source
     * @param country     the ISO country code of the source
     * @return a new {@link Source} instance with the given properties
     */
    public Source(String id, String name, String description, String url,
                  String category, String language, String country) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.url = url;
        this.category = category;
        this.language = language;
        this.country = country;
    }

    /**
     * Returns a human-readable representation of this source.
     *
     * @return a string describing this source
     */
    @Override
    public String toString() {
        return "Source{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", url='" + url + '\'' +
                ", category='" + category + '\'' +
                ", language='" + language + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
