package models;

import com.fasterxml.jackson.databind.JsonNode;
import services.NewsService;
import java.util.List;

import javax.inject.Inject;
import java.util.concurrent.CompletionStage;

/**
 * @author Pham Bao Quynh Nguyen
 * SourceViewModel responsible for retrieving information about news sources and their top articles.
 */

public class SourceViewModel {
    private final NewsService newsService;

    /**
     * Constructs a {@link SourceViewModel} with the specified {@link NewsService}
     * @param newsService the service responsible for fetching news and source data
     */
    @Inject
    public SourceViewModel(NewsService newsService) {
        this.newsService = newsService;
    }

    /**
     * Retrieves detailed information about a specific news source identified by its domain.
     * @param domain the domain name of the news source
     * @return A {@link CompletionStage} that resolves to a {@link JsonNode} containing information about the news source
     */
    public CompletionStage<JsonNode> getSourceInfo(String domain) {
        return newsService.getSourceInfo(domain);
    }

    /**
     * Retrieves the top 10 articles for a specific news source.
     * @param domain the domain name of the news source
     * @return A {@link CompletionStage} that resolves to a {@link List} of {@link JsonNode}, each representing an article.
     */
    public CompletionStage<List<JsonNode>> getTop10ArticlesForSpecificSource(String domain) {
        return newsService.getTop10ArticlesForSpecificSource(domain);
    }
}
