package models;
/**
 * Holds the count of a single word
 *
 */
public class WordCount {
    private final String word;
    private final int count;
    /**
     * Create a new {@code WordStatsResult}.
     *
     * @word
     * @param count for {@code word} entry;
     */
    public WordCount(String word, int count) {
        this.word = word;
        this.count = count;
    }

    /**
     * Returns the {@code word} entry
     *
     * @return word
     */
    public String getWord() {
        return word;
    }

    /**
     * Returns the {@code count} of a word
     *
     * @return count
     */
    public int getCount() {
        return count;
    }
}

