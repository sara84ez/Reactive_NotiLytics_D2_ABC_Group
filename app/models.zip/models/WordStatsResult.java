package models;

import java.util.List;
/**
 * Contains word count results
 *
 */
public class WordStatsResult {
    private final List<WordCount> counts;
    /**
     * Create a new {@code WordStatsResult}
     *
     * @param counts the list of {@code WordCount} entries
     */
    public WordStatsResult(List<WordCount> counts) {
        this.counts = counts;
    }

    /**
     * Returns the list of {@code WordCount} entries
     *
     * @return the list of word counts
     */
    public List<WordCount> getCounts() {
        return counts;
    }
}

