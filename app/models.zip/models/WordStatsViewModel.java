package models;

import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import services.NewsService;
import services.WordStatisticsService;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

/**
 * ViewModel responsible for preparing word statistics using stored session SearchResult data.
 */
public class WordStatsViewModel {
    private final WordStatisticsService statsService;
    private final NewsService newsService;
    private final Logger logger = LoggerFactory.getLogger("application");

    @Inject
    public WordStatsViewModel(WordStatisticsService statsService, NewsService newsService) {
        this.statsService = statsService;
        this.newsService = newsService;
    }

    /**
     * Asynchronously get word counts for up to maxArticles latest articles available in the user's session.
     *
     * @param query search query
     * @return CompletionStage of WordStatsResult containing counts and articleCount
     */
    public CompletionStage<WordStatsResult> getWordCountsForSessionAsync(String query) {

        if (query == null || query.trim().isEmpty()) {
            return CompletableFuture.completedFuture(new WordStatsResult(Collections.emptyList()));
        }

        return newsService.getSpecificNumberOfArticles(query, "publishedAt",50).thenApply(json -> {
            List<JsonNode> articlesList = new ArrayList<>();
            JsonNode articlesNode = json.get("articles");
            if (articlesNode != null && articlesNode.isArray()) {
                articlesNode.forEach(articlesList::add);
            }
            logger.info("Fetched {} articles for word count computation.",articlesList.size());
            List<WordCount> counts = statsService.computeWordCounts(articlesList);
            return new WordStatsResult(counts);
        });
    }
}
