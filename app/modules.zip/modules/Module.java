
package modules;

import com.google.inject.AbstractModule;
import org.apache.pekko.actor.typed.ActorRef;
import org.apache.pekko.actor.typed.ActorSystem;
import org.apache.pekko.actor.typed.javadsl.Behaviors;

import app.actors.SearchActor;
import app.actors.ResourceNewsActor;
import app.services.NewsApiService;
import app.services.NewsApiServiceMock;

/**
 * Guice module for wiring actors and services for D2.
 * Author: Sara Ezzati
 */
public class Module extends AbstractModule {

    @Override
    protected void configure() {
        bind(NewsApiService.class).to(NewsApiServiceMock.class).asEagerSingleton();

        ActorSystem<Void> system = ActorSystem.create(Behaviors.empty(), "notilytics-system");

        ActorRef<SearchActor.Command> search =
                system.systemActorOf(SearchActor.create(new NewsApiServiceMock()), "search-actor");

        ActorRef<ResourceNewsActor.Command> resources =
                system.systemActorOf(ResourceNewsActor.create(new NewsApiServiceMock()), "resource-actor");

        bind(ActorSystem.class).toInstance(system);
        bind(new com.google.inject.TypeLiteral<ActorRef<SearchActor.Command>>(){}).toInstance(search);
        bind(new com.google.inject.TypeLiteral<ActorRef<ResourceNewsActor.Command>>(){}).toInstance(resources);
    }
}
