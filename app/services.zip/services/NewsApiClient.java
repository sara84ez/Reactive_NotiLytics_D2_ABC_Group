package services;

import com.fasterxml.jackson.databind.JsonNode;
import com.typesafe.config.Config;
import models.Source;
import play.Logger;
import play.cache.AsyncCacheApi;
import play.libs.ws.WSClient;
import play.libs.ws.WSRequest;
import play.libs.ws.WSResponse;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

/**
 * Client responsible for talking to the external NewsAPI service.
 * <p>
 * The client knows how to:
 * <ul>
 *     <li>Build HTTP requests for the <code>/sources</code> endpoint</li>
 *     <li>Map JSON responses into {@link Source} objects</li>
 *     <li>Cache results using {@link AsyncCacheApi} to avoid unnecessary calls</li>
 * </ul>
 *
 * This class is designed to be a thin, reusable HTTP abstraction that can be
 * used from controllers, services, and view-models.
 *
 * @author Sara Ezzati
 * @version 1.0
 */
@Singleton
public class NewsApiClient {

    private static final Logger.ALogger log = Logger.of(NewsApiClient.class);

    /** Play WS client used to execute HTTP calls. */
    private final WSClient ws;
    /** Base URL for the NewsAPI service (e.g. https://newsapi.org/v2). */
    private final String baseUrl;
    /** API key configured for NewsAPI, if present. */
    private final Optional<String> apiKey;
    /** Cache used to store the result of expensive API calls. */
    private final AsyncCacheApi cache;
    /** Time-to-live for cached entries. */
    private final Duration cacheTtl;

    /**
     * Creates a new {@code NewsApiClient}.
     *
     * @param ws     WS client used to issue HTTP requests
     * @param config application configuration used to resolve base URL and API key
     * @param cache  cache instance for storing API results
     * @return a new {@link NewsApiClient} configured with the given dependencies
     */
    @Inject
    public NewsApiClient(WSClient ws, Config config, AsyncCacheApi cache) {
        this.ws = ws;
        this.cache = cache;
        this.baseUrl = config.hasPath("newsapi.baseUrl")
                ? config.getString("newsapi.baseUrl")
                : "https://newsapi.org/v2";
        this.apiKey = config.hasPath("newsapi.key")
                ? Optional.ofNullable(config.getString("newsapi.key"))
                : Optional.empty();
        int ttlSeconds = config.hasPath("newsapi.cacheTtlSeconds")
                ? config.getInt("newsapi.cacheTtlSeconds")
                : 300;
        this.cacheTtl = Duration.ofSeconds(ttlSeconds);
    }

    /**
     * Returns the list of news sources from NewsAPI, optionally filtered
     * by country, category and language.
     *
     * <p>Results are cached using {@link AsyncCacheApi} so repeated
     * calls with the same filter parameters will reuse the cached value.</p>
     *
     * @param country  optional ISO 3166 country code (e.g. {@code "us"})
     * @param category optional category filter (e.g. {@code "technology"})
     * @param language optional ISO language code (e.g. {@code "en"})
     * @return a {@link CompletionStage} resolving to a list of {@link Source} objects
     */
    public CompletionStage<List<Source>> getSources(Optional<String> country,
                                                    Optional<String> category,
                                                    Optional<String> language) {

        String cacheKey = "sources:" + country.orElse("") + ":"
                + category.orElse("") + ":" + language.orElse("");

        return cache.getOrElseUpdate(
                cacheKey,
                () -> fetchSources(country, category, language),
                (int) cacheTtl.getSeconds()
        );
    }

    /**
     * Performs the actual HTTP call to the NewsAPI <code>/sources</code> endpoint
     * and converts the JSON response into a list of {@link Source} objects.
     *
     * @param country  optional ISO 3166 country code
     * @param category optional category filter
     * @param language optional language filter
     * @return a {@link CompletionStage} resolving to a list of parsed {@link Source} objects
     */
    private CompletionStage<List<Source>> fetchSources(Optional<String> country,
                                                       Optional<String> category,
                                                       Optional<String> language) {

        if (apiKey.isEmpty() || apiKey.get().isBlank()) {
            log.warn("NEWSAPI_KEY not configured. Returning empty list.");
            return CompletableFuture.completedFuture(List.of());
        }

        WSRequest req = ws.url(baseUrl + "/sources")
                .addQueryParameter("apiKey", apiKey.get());
        country.filter(s -> !s.isBlank())
                .ifPresent(v -> req.addQueryParameter("country", v));
        category.filter(s -> !s.isBlank())
                .ifPresent(v -> req.addQueryParameter("category", v));
        language.filter(s -> !s.isBlank())
                .ifPresent(v -> req.addQueryParameter("language", v));

        return req.get()
                .thenApply(WSResponse::asJson)
                .thenApply(json -> {
                    List<Source> list = new ArrayList<>();
                    JsonNode sources = json.get("sources");
                    if (sources != null && sources.isArray()) {
                        for (JsonNode s : sources) {
                            Source src = new Source(
                                    text(s, "id"),
                                    text(s, "name"),
                                    text(s, "description"),
                                    text(s, "url"),
                                    text(s, "category"),
                                    text(s, "language"),
                                    text(s, "country")
                            );
                            list.add(src);
                        }
                    } else {
                        log.warn("Unexpected response from NewsAPI: " + json);
                    }
                    return list;
                });
    }

    /**
     * Helper method that reads a field from a {@link JsonNode} and returns
     * it as a string, handling missing or {@code null} values gracefully.
     *
     * @param node  JSON node containing the field
     * @param field name of the field to extract
     * @return the textual value of the field, or an empty string when
     *         the field is missing or null
     */
    private static String text(JsonNode node, String field) {
        JsonNode n = node.get(field);
        return (n == null || n.isNull()) ? "" : n.asText();
    }
}
