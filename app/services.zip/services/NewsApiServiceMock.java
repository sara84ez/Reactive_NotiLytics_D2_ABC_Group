package app.services;

import app.models.Article;
import app.models.SourceInfo;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

/**
 * Mock service for unit tests. Never calls live API.
 * Fully deterministic output for testing actors.
 *
 * Author: Sara Ezzati
 */
public class NewsApiServiceMock implements NewsApiService {

    @Override
    public CompletionStage<List<Article>> searchArticles(String query) {
        Article a = new Article("id1", "Test Title", "Test Description", "http://test.com", "Test Source");
        return CompletableFuture.completedFuture(List.of(a));
    }

    @Override
    public CompletionStage<List<SourceInfo>> getSources(String country, String category, String language) {
        SourceInfo s = new SourceInfo("mock-source", "Mock Source", country, category, language, "http://mock.com");
        return CompletableFuture.completedFuture(List.of(s));
    }
}
