package services;

import java.nio.charset.StandardCharsets;
import java.net.URLEncoder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.net.InternetDomainName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import play.libs.ws.*;
import com.fasterxml.jackson.databind.JsonNode;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.concurrent.CompletionStage;
import play.cache.AsyncCacheApi;
import java.util.List;

/**
 * @author Pham Bao Quynh Nguyen
 * Service class responsible for fetching news and source information from the NewsAPI.
 */
/**
 * Service responsible for calling the NewsAPI endpoints and
 * transforming the responses into JSON nodes used by the
 * view models and controllers.
 *
 * @author Sara Ezzati
 */
public class NewsService {
    private final Logger logger = LoggerFactory.getLogger("application");
    private final WSClient ws;
    private final String apiKey = System.getenv("NEWSAPI_KEY");
    private final AsyncCacheApi cache;
    private final ObjectMapper objectMapper;

    /**
     * Constructs a {@link NewsService} with the specified dependencies.
     * @param ws
     * @param cache
     * @param objectMapper
     */
    /**
     * Creates a new {@code NewsService} instance.
     *
     * @param ws           WS client used to perform HTTP requests
     * @param cache        cache for storing NewsAPI responses
     * @param objectMapper JSON object mapper used to parse responses
     * @return a new {@link NewsService} configured with the given dependencies
     */
    @Inject
    public NewsService(WSClient ws, AsyncCacheApi cache, ObjectMapper objectMapper) {
        this.ws = ws;
        this.cache = cache;
        this.objectMapper = objectMapper;
    }

    /**
     * Searches news articles based on a query and sorting option.
     * The results are cached for 5 minutes to reduce redundant API calls for identical queries.
     * @param query the search keyword or phrase
     * @param sortBy the sorting criterion
     * @return A {@link CompletionStage} resolving to a {@link JsonNode} containing the search results
     */
    /**
     * Performs a news search using the given query and sort criteria.
     *
     * @param query  search keywords to send to NewsAPI
     * @param sortBy sort order requested (for example, "publishedAt")
     * @return a {@link CompletionStage} resolving to the JSON search results
     */
    public CompletionStage<JsonNode> searchNews(String query, String sortBy) {
        String cacheKey = query.trim().toLowerCase() + ":" + sortBy;
        String encodedQuery = "\"" + URLEncoder.encode(query.trim(), StandardCharsets.UTF_8) + "\"";

        String url = "https://newsapi.org/v2/everything?q=" + encodedQuery +
                "&pageSize=10&sortBy=" + sortBy +
                "&apiKey=" + apiKey;

        return cache.getOrElseUpdate( cacheKey,
                () -> ws.url(url)
                        .get()
                        .thenApply(WSResponse::asJson)
                        .thenApply(
                                jsonNode -> {
                                    logger.info("Fetch from newsapi.org and add news in cache");
                                    return jsonNode;
                                }
                        ),
                300);
    }

    /**
     * Retrieves detailed information about a news source for a given domain.
     * <p>
     * The result is cached for 5 minutes to optimize performance.
     * </p>
     * @param domain the domain name of the news source
     * @return A {@link CompletionStage} resolving to a {@link JsonNode} containing source information, or an empty object if no match is found
     */
    public CompletionStage<JsonNode> getSourceInfo(String domain) {
        String sourcesUrl = "https://newsapi.org/v2/sources?apiKey=" + apiKey;
        String cacheKey = "sourceInfo_" + domain;

        return cache.getOrElseUpdate(
                cacheKey,
                () -> ws.url(sourcesUrl)
                        .get()
                        .thenApply(WSResponse::asJson)
                        .thenApply(json -> {
                            JsonNode sources = json.get("sources");
                            if (sources != null && sources.isArray()) {
                                for (JsonNode source : sources) {
                                    String url = source.get("url").asText("");
                                    if (url.contains(domain)) {
                                        return source; // return the matching source
                                    }
                                }
                            }
                            // if no match found
                            return objectMapper.createObjectNode();
                        }),
                300 // cache for 5 minutes
        );
    }

    /**
     * Retrieves the top 10 articles for a specific news source domain.
     * <p>
     * The method first normalizes the provided domain name, stripping any
     * {@code "www."} prefix and ensuring it represents a valid public suffix using
     * {@link InternetDomainName}. If the domain is invalid, the method logs a warning
     * but continues the query.
     * </p>
     * <p>
     * Results are cached for 5 minutes to improve efficiency.
     * </p>
     * @param domain the domain of the source website
     * @return A {@link CompletionStage} resolving to a {@link List} of {@link JsonNode},
     * each representing an article. Returns an empty list if no articles are found.
     */
    /**
     * Retrieves the top 10 articles for the given domain.
     *
     * @param domain the domain whose articles should be fetched
     * @return a {@link CompletionStage} resolving to a list of article JSON nodes
     */
    public CompletionStage<List<JsonNode>> getTop10ArticlesForSpecificSource(String domain) {
        String editedDomain = domain.startsWith("www.")? domain.substring(4): domain;
        try {
            InternetDomainName domainName = InternetDomainName.from(editedDomain);
            if (domainName.isUnderPublicSuffix()) {
                editedDomain = domainName.topPrivateDomain().toString();
            }
        } catch (IllegalArgumentException e) {
            logger.warn("Domain name {} may be invalid, but still trying to query", editedDomain);
        }
        String url = "https://newsapi.org/v2/everything?domains=" + editedDomain + "&pageSize=10&apiKey=" + apiKey;
        String cacheKey = "top10_" + editedDomain;

        return cache.getOrElseUpdate(
                cacheKey,
                () -> ws.url(url)
                        .get()
                        .thenApply(WSResponse::asJson)
                        .thenApply(json -> {
                            JsonNode articlesNode = json.get("articles");
                            List<JsonNode> list = new ArrayList<>();
                            if (articlesNode != null && articlesNode.isArray() && !articlesNode.isEmpty()) {
                                logger.info("Adding something");
                                articlesNode.forEach(list::add); // convert ArrayNode to List<JsonNode>
                            } else {
                                logger.info("Return list is empty");
                            }
                            return list; // always returns a List<JsonNode>
                        }),
                300 // cache duration in seconds
        );
    }
    /**
     * Searches news articles based on a query, sorting option and number of articles.
     * The results are cached for 5 minutes to reduce redundant API calls for identical queries.
     * @param query the search keyword or phrase
     * @param sortBy the sorting criterion
     * @param pageSize the number of articles to retrieve
     * @return A {@link CompletionStage} resolving to a {@link JsonNode} containing the search results
     */
    public CompletionStage<JsonNode> getSpecificNumberOfArticles(String query, String sortBy, int pageSize) {
        String cacheKey = query.trim().toLowerCase() + ":" + sortBy+ ":"+"pageSize=" + pageSize;
        String encodedQuery = "\"" + URLEncoder.encode(query.trim(), StandardCharsets.UTF_8) + "\"";

        String url = "https://newsapi.org/v2/everything?q=" + encodedQuery +
                "&pageSize="+pageSize+"&sortBy=" + sortBy +
                "&apiKey=" + apiKey;

        return cache.getOrElseUpdate( cacheKey,
                () -> ws.url(url)
                        .get()
                        .thenApply(WSResponse::asJson)
                        .thenApply(
                                jsonNode -> {
                                    logger.info("Fetch 50 articles from newsapi.org and add news in cache");
                                    return jsonNode;
                                }
                        ),
                300);
    }
}
