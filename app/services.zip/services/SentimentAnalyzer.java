package services;
import com.fasterxml.jackson.databind.JsonNode;
import models.Sentiment;
import models.SentimentAnalysisResult;
import java.util.*;
import java.util.regex.Pattern;


/**
 * Sentiment analyzer class for news article description.
 * @author Sadman Arif Wamim
 */
public class SentimentAnalyzer {

    private static final Set<String> HAPPY = Set.of(
            "good","great","excellent","amazing","love","happy","joy","win","success","uplift","yay","cheer","optimistic","positive"
    );

    private static final Set<String> SAD = Set.of(
            "bad","terrible","awful","sad","cry","loss","fear","hate","angry","tragedy","down", "depress","negative","concern","worry","fatal","dead","death", "warming"
    );

    /**
     * Regex pattern used to split text into individual tokens.
     * letters, numbers, colons and symbols as tokens for analysis.
     */
    private static final Pattern SPLIT = Pattern.compile("[^\\p{L}\\p{N}:()\\p{So}\\p{Sk}]+");

    /**
     * Perform sentiment analysis on a single article based on description.
     * Counts the predefined words and computes their ratio.
     * If ratio exceeds 70%, classify the article as HAPPY,
     * else if ratio goes below 40%, classify as SAD
     * else for other cases, define it as NEUTRAL
     * @param article is the article with a field called "description"
     * @return detected Sentiment: HAPPY, SAD or NEUTRAL
     */
    public static Sentiment classifyArticle(JsonNode article) {
        try {
            if(article == null || article.isNull()) return Sentiment.NEUTRAL;

            String text = Optional.ofNullable(article.get("description"))
                    .filter(n -> !n.isNull())
                    .map(JsonNode::asText)
                    .orElse("");

            if(text.isBlank()) return Sentiment.NEUTRAL;

            List<String> tokens = Arrays.stream(SPLIT.split(text.toLowerCase(Locale.ROOT)))
                    .filter(t -> !t.isBlank())
                    .toList();

            long happyHits = tokens.stream()
                    .filter(HAPPY::contains)
                    .count();

            long sadHits = tokens
                    .stream()
                    .filter(SAD::contains)
                    .count();

            long totalHits = happyHits + sadHits;

            if(totalHits == 0) return Sentiment.NEUTRAL;

            double happyRatio = happyHits * 1.0/ totalHits;

            if(happyRatio > 0.7) return Sentiment.HAPPY;
            if(happyRatio < 0.4) return Sentiment.SAD;
            return Sentiment.NEUTRAL;

        } catch(Exception e) {
            return Sentiment.NEUTRAL;
        }
    }

    /**
     * Takes a stream of 50 articles and computes the aggregate.
     * Classify the stream as HAPPY, SAD or NEUTRAL
     * depending on the ratio. For cases beyond the Happy and Sad cases,
     * All others are defined as Neutral.
     * @param articles a list of articles with a field called "description".
     * @return SentimentAnalysisResult containing the overall sentiment
     */
    public static SentimentAnalysisResult analyzeStream(List<JsonNode> articles) {
        try{
            List<JsonNode> first50 = articles.stream()
                    .limit(50)
                    .toList();

            List<Sentiment> perArticle = first50.stream()
                    .map(article -> {
                        try {
                            return SentimentAnalyzer.classifyArticle(article);
                        } catch (Exception e) {
                            return Sentiment.NEUTRAL;
                        }
                    })
                    .toList();

            long happyArticles = perArticle.stream()
                    .filter(s -> s == Sentiment.HAPPY)
                    .count();

            long sadArticles = perArticle.stream()
                    .filter(s -> s == Sentiment.SAD)
                    .count();

            long totalArticles = perArticle.size();

            if(totalArticles == 0) {
                return new SentimentAnalysisResult(Sentiment.NEUTRAL, 0,0,0,0);
            }

            int sum = perArticle.stream().
                    mapToInt(s ->
                    s == Sentiment.HAPPY ? 1 : (s == Sentiment.SAD ? -1 : 0)
            ).sum();

            Sentiment overall = sum > 0 ? Sentiment.HAPPY : sum < 0 ? Sentiment.SAD : Sentiment.NEUTRAL;

            double happyRatio = happyArticles * 1.0 / totalArticles;
            double sadRatio = sadArticles * 1.0 / totalArticles;

            return new SentimentAnalysisResult(overall, happyRatio, sadRatio, (int)happyArticles, (int)sadArticles);
        } catch(Exception e) {
            return new SentimentAnalysisResult(Sentiment.NEUTRAL, 0,0,0,0);
        }
    }
}
