package services;

import com.fasterxml.jackson.databind.JsonNode;
import models.WordCount;

import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class WordStatisticsService {
    private static final Pattern SPLIT_PATTERN = Pattern.compile("\\W+");

    /**
     * Compute word counts from the articles' "description" field.
     * Uses Java Streams API. Returns a list sorted by descending frequency.
     *
     * @param articles list of JsonNode articles
     * @return sorted list of WordCount
     */
    public List<WordCount> computeWordCounts(List<JsonNode> articles) {
        if (articles == null || articles.isEmpty()) {
            return Collections.emptyList();
        }

        Function<JsonNode, Instant> publishedAt = node -> {
            try {
                JsonNode p = node.get("publishedAt");
                if (p != null && !p.isNull()) {
                    return Instant.parse(p.asText());
                }
            } catch (DateTimeParseException ignored) {}
            return Instant.EPOCH;
        };

        Function<JsonNode, String> extractText = node -> {
            String[] fields = new String[]{"description", "title", "content"};
            for (String f : fields) {
                JsonNode fld = node.get(f);
                if (fld != null && !fld.isNull()) {
                    String v = fld.asText("").trim();
                    if (!v.isEmpty()) return v;
                }
            }
            return "";
        };

        Map<String, Integer> freq = articles.stream()
            .sorted(Comparator.comparing(publishedAt).reversed())
            .map(extractText)
            .filter(s -> s != null && !s.trim().isEmpty())
            .flatMap(s -> Arrays.stream(SPLIT_PATTERN.split(s)))
            .map(String::toLowerCase)
            .filter(w -> !w.isEmpty())
            .collect(Collectors.toMap(Function.identity(), w -> 1, Integer::sum));

        return freq.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder())
                    .thenComparing(Map.Entry.comparingByKey()))
            .map(e -> new WordCount(e.getKey(), e.getValue()))
            .collect(Collectors.toList());
    }
}
