package app.websocket;

import org.apache.pekko.actor.typed.ActorRef;
import org.apache.pekko.actor.typed.javadsl.*;
import app.actors.UserActor;

/**
 * NotiLyticsSocket bridges between the WebSocket and UserActor.
 *
 * It receives client text messages and forwards commands to UserActor.
 * It receives push updates from UserActor and sends them to the WebSocket.
 *
 * Author: Sara Ezzati
 */
public class NotiLyticsSocket extends AbstractBehavior<NotiLyticsSocket.Command> {

    public interface Command {}

    /** Incoming WebSocket text from client */
    public static final class FromClient implements Command {
        public final String text;
        public FromClient(String t){ text=t; }
    }

    /** Outgoing text to WebSocket */
    public interface WebSocketOut {
        void sendText(String text);
    }

    private final ActorRef<UserActor.Command> user;
    private final WebSocketOut out;

    public static Behavior<Command> create(ActorRef<UserActor.Command> user, WebSocketOut out) {
        return Behaviors.setup(ctx -> new NotiLyticsSocket(ctx, user, out));
    }

    private NotiLyticsSocket(ActorContext<Command> ctx,
                             ActorRef<UserActor.Command> user,
                             WebSocketOut out) {
        super(ctx);
        this.user = user;
        this.out = out;
    }

    @Override
    public Behavior<Command> onMessage(Command msg) {

        if(msg instanceof FromClient m){
            // naive protocol:
            if(m.text.startsWith("search:")){
                String q = m.text.substring(7);
                user.tell(new UserActor.UserSearch(q));
            }
            else if(m.text.startsWith("sources:")){
                // format: sources:country,category,language
                String[] p = m.text.substring(8).split(",");
                String c = p.length>0 ? p[0] : "";
                String cat = p.length>1 ? p[1] : "";
                String lang = p.length>2 ? p[2] : "";
                user.tell(new UserActor.UserRequestSources(c,cat,lang));
            }
        }

        return this;
    }

    /** Called by UserActor to push data to client */
    public void push(String json){
        out.sendText(json);
    }
}
